<?php


namespace conversor;


class ConversorTemperaturas
{

    function CelsiusToFarenheit($celsius){
        if($celsius>500){
            return PHP_FLOAT_MAX;
        }

        return $celsius*(9/5)+32;
    }

    function FarenheitToCelsius($farenheit){
        if($farenheit>932){
            return PHP_FLOAT_MAX;
        }

        return ($farenheit-32)*(5/9);
    }


}