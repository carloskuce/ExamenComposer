<?php

namespace conversor;


class ConversorTemperaturasTest extends \PHPUnit\Framework\TestCase
{

    public function testCelsiusToFarenheit()
    {
        $conversor= new ConversorTemperaturas();

        $conversor=$conversor->CelsiusToFarenheit(0);
        $this->assertEquals(32,$conversor);

        $conversor= new ConversorTemperaturas();
        $conversor=$conversor->CelsiusToFarenheit(50);
        $this->assertEquals(122,$conversor);

        $conversor= new ConversorTemperaturas();
        $conversor=$conversor->CelsiusToFarenheit(500);
        $this->assertEquals(932,$conversor);

        $conversor= new ConversorTemperaturas();
        $conversor=$conversor->CelsiusToFarenheit(501);
        $this->assertEquals(PHP_FLOAT_MAX,$conversor);
    }

    public function testFarenheitToCelsius()
    {
        $conversor= new ConversorTemperaturas();

        $conversor=$conversor->FarenheitToCelsius(0);
        $this->assertEquals(-17.78,floor($conversor*100)/100);

        $conversor= new ConversorTemperaturas();
        $conversor=$conversor->FarenheitToCelsius(200);
        $this->assertEquals(93.33,floor($conversor*100)/100);

        $conversor= new ConversorTemperaturas();
        $conversor=$conversor->FarenheitToCelsius(600);
        $this->assertEquals(315.55,floor($conversor*100)/100);

        $conversor= new ConversorTemperaturas();
        $conversor=$conversor->FarenheitToCelsius(932);
        $this->assertEquals(500,$conversor);

    }
}
