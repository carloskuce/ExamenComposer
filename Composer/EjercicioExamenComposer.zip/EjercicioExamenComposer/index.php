<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<?php

require "vendor/autoload.php";

$conversor= new conversor\ConversorTemperaturas();

echo "Comprobamos que 50ºC son  ".$conversor->CelsiusToFarenheit(50)." ºF<br>";
echo "Comprobamos que 50ºF son  ".$conversor->FarenheitToCelsius(50)." ºC."

?>
</body>
</html>



